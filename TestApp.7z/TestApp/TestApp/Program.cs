﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {

            // Rules:
            // Convert the letter after a vowel to capitals aeiou
            // Don't capitalise vowels
            // Don't capitalise letters after a space

            test();
            Console.Read();
        }

        //public static void Main()
        //{
        //    test();
        //}

        public static void test()
        {
            Console.WriteLine(ConvertLetters("hello world") == "heLlo woRld");
            Console.WriteLine(ConvertLetters("great answer") == "greaT aNsweR");
            Console.WriteLine(ConvertLetters("beautiful answer") == "beauTiFuL aNsweR");
        }

        public static string ConvertLetters(string txt)
        {
            // You code here
            char[] vowels = {'a', 'e','i','o','u' };
            StringBuilder rtnstr = new StringBuilder();

            bool isVowel = false;

            char prev = ' ';

            for(int  i = 0; i < txt.Length; i++)
            {
                char xrt = txt[i];

                if(i > 0)
                {
                    prev = txt[i - 1];
                }

                if(vowels.Contains(prev) && !vowels.Contains(xrt))
                {
                    rtnstr.Append(xrt.ToString().ToUpper());
                }
                else
                {
                    rtnstr.Append(xrt.ToString());
                }

            }

            return rtnstr.ToString();
        }

    }
}
